#!/usr/bin/env python3
# -*- encoding: utf-8 -*-

"""
logging framework
"""

logfile_stream = None

