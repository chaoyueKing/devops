#!/usr/bin/env python3
# -*- encoding: utf-8 -*-
"""

"""



class ScanComparer(AbstractScanComparer):
    """
        TODO: Not Implemented yet
    """

